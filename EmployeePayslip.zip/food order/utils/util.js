const fs = require('fs');
const xlsx = require('xlsx');

function parseExcel(filePath) {
    const workbook = xlsx.readFile(filePath);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    return xlsx.utils.sheet_to_json(sheet);
}

function parseJSON(filePath) {
    const rawData = fs.readFileSync(filePath);
    return JSON.parse(rawData);
}

module.exports = { parseExcel, parseJSON };
