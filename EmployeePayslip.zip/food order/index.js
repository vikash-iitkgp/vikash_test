require('dotenv').config();
const { parseExcel, parseJSON } = require('./utils/util');
const Employee = require('./Classes/Employee');
const Attendance = require('./Classes/EmployeeAttendance');
const SalaryCalculator = require('./Classes/SalaryCalculator');

// Load configuration
const EPF_PERCENTAGE = parseFloat(process.env.EPF_PERCENTAGE);
const TOTAL_WORKING_DAYS = parseInt(process.env.TOTAL_WORKING_DAYS);

// Load data
const employeesData = parseJSON('./data/employees.json');
const attendanceData = parseExcel('./data/attendance.xlsx');

// Create employee instances
const employees = employeesData.map(emp => new Employee(emp.id, emp.name, emp.salary.basic, emp.salary.hra, emp.salary.special));

// Parse attendance and map to EmployeeID
const attendanceMap = {};
attendanceData.forEach(record => {
    const employeeID = record.EmployeeID;
    const leaveBalane=record.LeaveBalance;
    const attendanceDays = Object.values(record).slice(2); // Skip EmployeeID and LeaveBalancecolumn
    attendanceMap[employeeID] = new Attendance(employeeID, leaveBalane,attendanceDays);
});

// Command-line query
const employeeID = process.argv[2];
if (!employeeID) {
    console.error('Please provide an Employee ID.');
    process.exit(1);
}

const employee = employees.find(emp => emp.id === employeeID);
if (!employee) {
    console.error('Employee not found.');
    process.exit(1);
}

const attendance = attendanceMap[employeeID];
if (!attendance) {
    console.error('Attendance data not found for the employee.');
    process.exit(1);
}

// Create salary calculator instance
const salaryCalculator = new SalaryCalculator(employee, attendance, EPF_PERCENTAGE, TOTAL_WORKING_DAYS);

// Calculate salary
const grossSalary = salaryCalculator.getGrossSalary();
//const netSalary = salaryCalculator.getNetSalary();
const attendanceSalary = salaryCalculator.calculateAttendanceBasedSalary();

// Output all salary components and details
console.log(`Employee: ${employee.name}`);
console.log(`Basic Salary: ${employee.basic}`);
console.log(`Gross Salary: ${grossSalary}`);
//console.log(`Net Salary after EPF (${EPF_PERCENTAGE}% on Basic Salary): ${netSalary}`);
console.log(`Calculated Salary based on attendance (${attendance.getTotalAttendance()} days): `);
console.log(`
  - Basic: ${attendanceSalary.basic}
  - HRA: ${attendanceSalary.hra}
  - Special: ${attendanceSalary.special}
  - Attendance Salary: ${attendanceSalary.attendanceSalary}
  - Total EPF: ${attendanceSalary.totalEPF}
  - Net Salary after Attendance: ${attendanceSalary.netSalary}
`);