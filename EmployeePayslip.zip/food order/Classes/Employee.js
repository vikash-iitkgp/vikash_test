class Employee {
    constructor(id, name, basic, hra, special) {
        this.id = id;
        this.name = name;
        this.basic = basic;
        this.hra = hra;
        this.special = special;
    }
}

module.exports = Employee;
