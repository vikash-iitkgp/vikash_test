class FoodItem {
    constructor(id, name, price, category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
    }

    display() {
        return `${this.name} (${this.category}) - ₹${this.price}`;
    }
}

module.exports = FoodItem;
