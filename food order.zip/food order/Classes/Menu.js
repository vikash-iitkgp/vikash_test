class Menu {
    constructor() {
        this.items = [];
    }

    addItem(item) {
        this.items.push(item);
    }

    display() {
        console.log('--- Menu ---');
        this.items.forEach(item => console.log(`${item.id}. ${item.display()}`));
    }
}

module.exports = Menu;
