function calculateTotal(order) {
    return order.reduce((total, item) => total + item.price, 0);
}

function getOrderTimestamp() {
    const now = new Date();
    return now.toISOString();
}

module.exports = { calculateTotal, getOrderTimestamp };
