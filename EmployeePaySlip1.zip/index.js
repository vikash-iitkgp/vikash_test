require("dotenv").config();
const readline = require("readline");
const {
  getEmployeeByID,
  getEmployeesByName,
  addNewEmployee,
} = require("./Controllers/employeeController");
const {
  mapAttendance,
  addAttendanceRecord,
} = require("./Controllers/attendanceController");
const {
  calculateEmployeeSalary,
  displaySalaryDetails,
} = require("./Controllers/salaryController");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

// Map attendance data
let attendanceMap = mapAttendance();


// Start the command handling
const handleCommand = () => {
    console.log("\nWelcome to the Employee Salary Manager!");
    console.log("Available Commands:");
    console.log("1. getSalary - Get the salary details of an employee.");
    console.log("2. addNew - Add a new employee.");
    console.log("3. getAllSalaries - Get salary details for all employees.");
    console.log("4. exit - Exit the application.\n");
    rl.question("Enter Command: ", (command) => {
    const [action] = command.trim().split(" ");

    switch (action) {
      case "1":
        handleGetSalary();
        break;

      case "2":
        handleAddNew();
        break;

      case "3":
        handleGetAllSalaries();
        break;

      case "4":
        console.log("Exiting the program. Goodbye!");
        rl.close();
        return;

      default:
        console.error("Invalid command. Please try again.\n");
        setTimeout(handleCommand, 100);
    }
    //setTimeout(handleCommand, 100); // Give some delay for better user experience
  });
};

const handleGetSalary = () => {
  rl.question("Options--> 1: Get by ID 2: Get by Name, 3: Main Menu, 4:Exit -->", (choice) => {
    if (choice.toLowerCase() == 1) {
      handleGetSalaryByID();
    } else if (choice.toLowerCase() == 2) {
      handleGetSalaryByName();
    }else if(choice.toLowerCase() == 3){
        handleCommand()
    }else if(choice.toLowerCase() == 4){
        console.log("Exiting the program. Goodbye!");
        rl.close();
        return;
    }else {
      console.error('Invalid choice. Please enter "name" or "id".\n');
      handleGetSalary(); // Re-prompt for a valid choice
    }
  });
};

const handleGetSalaryByID = () => {
  rl.question("Enter Employee ID: ", (employeeID) => {
    const employee = getEmployeeByID(employeeID);
    if (!employee) {
      console.error("Employee not found.\n");
      handleGetSalaryByID(); // Re-prompt to enter ID again
      return;
    }
    attendanceMap = mapAttendance();
    const attendance = attendanceMap[employeeID];
    if (!attendance) {
      console.error("Attendance data not found for the employee.\n");
      handleGetSalaryByID(); // Re-prompt to enter ID again
      return;
    }
    const salaryDetails = calculateEmployeeSalary(employee, attendance);
    displaySalaryDetails(employee, salaryDetails);
    setTimeout(handleCommand, 100); // Go back to main menu
  });
};

const handleGetSalaryByName = () => {
  rl.question("Enter Employee Name: ", (employeeName) => {
    const employees = getEmployeesByName(employeeName);
    if (employees.length === 0) {
      console.log("No employee found with the given name. Please try again.\n");
      handleGetSalaryByName(); // Re-prompt to enter name again
      return;
    } else if (employees.length === 1) {
      const attendance = attendanceMap[employees[0].id];
      const salaryDetails = calculateEmployeeSalary(employees[0], attendance);
      displaySalaryDetails(employees[0], salaryDetails);
      setTimeout(handleCommand, 100); // Go back to main menu
    } else {
      console.log(
        "Multiple employees found with the same name. Please choose one by ID:"
      );
      employees.forEach((emp) =>
        console.log(`- ID: ${emp.id}, Name: ${emp.name}`)
      );
      setTimeout(handleGetSalaryByID, 100); // Go back to main menu after listing
    }
  });
};

const handleAddNew = () => {
  rl.question("Enter Employee Name: ", (name) => {
    rl.question("Enter Employee ID: ", (id) => {
      rl.question("Enter Employee Basic Salary: ", (basicSalary) => {
        rl.question("Enter Employee HRA: ", (hra) => {
          rl.question("Enter Employee Special Allowance: ", (special) => {
            rl.question("Enter Leave Balance:", (leaveBal) => {
              rl.question(
                "Enter Comma sepereated Attendence String (Ex:P,P,WO,A,A,A,P,H,O) Balance:",
                (attendencestr) => {
                  try {
                    // Add new employee to the system
                    const newEmployee = {
                      id,
                      name,
                      salary: {
                        basic: parseFloat(basicSalary),
                        hra: parseFloat(hra),
                        special: parseFloat(special),
                      },
                    };

                    if (addNewEmployee(newEmployee)) {
                      addAttendanceRecord(id, leaveBal, attendencestr);
                      rl.question("Enter 1 for get Salary last added, 2 for initial command,3 to add new",(option) => {
                          if (option == 1) {
                            const employee = getEmployeeByID(id);
                            if (!employee) {
                              console.error("Employee not found.\n");
                              handleGetSalaryByID(); // Re-prompt to enter ID again
                              return;
                            }
                            attendanceMap = mapAttendance();
                            const attendance = attendanceMap[id];
                            if (!attendance) {
                              console.error(
                                "Attendance data not found for the employee.\n"
                              );
                              handleGetSalaryByID(); // Re-prompt to enter ID again
                              return;
                            }
                            const salaryDetails = calculateEmployeeSalary(
                              employee,
                              attendance
                            );
                            displaySalaryDetails(employee, salaryDetails);
                            setTimeout(handleCommand, 100); // Go back to main menu
                          } else if (option == 2) {
                            setTimeout(handleCommand, 100);
                          } else if (option == 3) {
                            handleAddNew();
                          }
                        }
                      );
                    } else {
                        rl.question("1: Enter detail again, 2: Main menu --> ", (option) => {
                            if(option ==1){
                                handleAddNew()
                            }else if(option==2){
                                handleCommand()
                            }else{
                                console.log("Wrong input");
                                console.log("Exiting the program. Goodbye!");
                                rl.close();
                                return;
                            }
                        });
                        
                    }

                   

                    
                  } catch (error) {
                    console.error(`Error: ${error.message}\n`);
                  }
                }
              );
            });
          });
        });
      });
    });
  });
};

const handleGetAllSalaries = () => {
  console.log("\nCalculating salaries for all employees...\n");
  const allEmployees = Object.keys(attendanceMap)
    .map(getEmployeeByID)
    .filter(Boolean);

  if (allEmployees.length === 0) {
    console.log("No employees found.\n");
    return;
  }

  allEmployees.forEach((employee) => {
    const attendance = attendanceMap[employee.id];
    if (attendance) {
      const salaryDetails = calculateEmployeeSalary(employee, attendance);
      displaySalaryDetails(employee, salaryDetails);
    } else {
      console.error(
        `Attendance data not found for Employee ID: ${employee.id}\n`
      );
    }
  });
  rl.question("1: Main Menu, 2: Exit --> ", (option) => {
    if (option == 1) {
        setTimeout(handleCommand, 100);
    }else  if (option == 2) {
        console.log("Exiting the program. Goodbye!");
        rl.close();
        return;
    }else{
        console.log("Wrong input");
        console.log("Exiting the program. Goodbye!");
        rl.close();
        return;
    }
  });
};

handleCommand();
