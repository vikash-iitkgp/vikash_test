const fs = require('fs');
const xlsx = require('xlsx');

function readExcelToJson(filePath) {
    try{
        const workbook = xlsx.readFile(filePath);
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        return xlsx.utils.sheet_to_json(sheet);
    }catch(error){
        console.error('An error occurred in reading excel:', error.message);
    }
    
}

/**
 * Appends a CSV string to the last row of an Excel file.
 *
 * @param {string} filePath - The path to the Excel file.
 * @param {string} csvString - The CSV string to add as the last row.
 */
function appendCsvToExcel(filePath, csvString) {
    try {
        // Load or create a workbook
        let workbook;
        try {
            workbook = xlsx.readFile(filePath);
        } catch (err) {
            console.log(`File not found. Creating a new Excel file: ${filePath}`);
            workbook = xlsx.utils.book_new();
        }

        // Get the first worksheet or create one
        const sheetName = workbook.SheetNames[0] || 'Sheet1';
        let worksheet = workbook.Sheets[sheetName];

        if (!worksheet) {
            worksheet = xlsx.utils.aoa_to_sheet([]); // Create a new worksheet if none exists
            xlsx.utils.book_append_sheet(workbook, worksheet, sheetName);
        }

        // Convert worksheet to array of arrays
        const sheetData = xlsx.utils.sheet_to_json(worksheet, { header: 1 });

        // Parse the CSV string into an array
        const csvArray = csvString.split(',');

        // Append the array as the last row
        sheetData.push(csvArray);

        // Convert the updated data back to a worksheet
        worksheet = xlsx.utils.aoa_to_sheet(sheetData);
        workbook.Sheets[sheetName] = worksheet;

        // Save the workbook
        xlsx.writeFile(workbook, filePath);

        console.log('Data appended successfully!');
    } catch (error) {
        console.error('An error occurred:', error.message);
    }
}

function parseJSON(filePath) {
    try {
        const rawData = fs.readFileSync(filePath);
        return JSON.parse(rawData);
    } catch (error) {
        console.error('Error REading employee data:', error.message);
        return;
    }
    
}

// Utility to write employee data
const writeEmployeeData = (data, filePath) => {
    try {
        console.log(data);
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error writing employee data:', error.message);
        return false;
    }
};

module.exports = { readExcelToJson, appendCsvToExcel, parseJSON, writeEmployeeData};
