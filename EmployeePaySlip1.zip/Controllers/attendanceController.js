const fs = require('fs');
const xlsx = require('xlsx');
const { readExcelToJson,appendCsvToExcel } = require('../utils/util');
const Attendance = require('../Classes/EmployeeAttendance');
const attendanceDataFile = './data/attendance.xlsx';

// Load attendance data
let attendanceData = [];
try {
    attendanceData = readExcelToJson(attendanceDataFile);
} catch (error) {
    console.error('Error loading attendance data:', error.message);
}

// Controller methods
const mapAttendance = () => {
    const attendanceMap = {};
    attendanceData.forEach((record) => {
        try {
            const employeeID = record.EmployeeID;
            const leaveBalance = parseInt(record.LeaveBalance) || 0;
            const attendanceDays = Object.values(record).slice(2); // Skip EmployeeID and LeaveBalance
            attendanceMap[employeeID] =new Attendance(employeeID, leaveBalance,attendanceDays);
        } catch (error) {
            console.error('Error mapping attendance:', error.message);
        }
    });
    return attendanceMap;
};

const addAttendanceRecord = (id,leaveBal,attendencestr) => {
    let data=id+','+leaveBal+','+attendencestr;
    appendCsvToExcel(attendanceDataFile,data);
    attendanceData = readExcelToJson(attendanceDataFile);
};

module.exports = {
    mapAttendance,
    addAttendanceRecord,
};
