const fs = require('fs');
const { parseJSON ,writeEmployeeData} = require('../utils/util');

const Employee = require('../Classes/Employee');
const employeesDataFile = './data/employees.json';

// Load employee data
let employeesData = [];
try {
    employeesData = parseJSON(employeesDataFile);
} catch (error) {
    console.error('Error loading employees data:', error.message);
}
let employees = employeesData.map(emp => new Employee(emp.id, emp.name, emp.salary.basic, emp.salary.hra, emp.salary.special));


// Controller methods
const getEmployeeByID = (employeeID) => employees.find(emp => emp.id === employeeID);
const getEmployeesByName = (name) =>
    employees.filter((emp) => emp.name.toLowerCase().includes(name.toLowerCase()));

const addNewEmployee = (employee) => {
    // Check if employee ID already exists
    if (getEmployeeByID(employee.id)) {
        console.error('Error: Employee ID already exists.');
        return false;
    }

    // Add to employeesData array
    employeesData.push(employee);

    // Write updated data to file
    const writeSuccess = writeEmployeeData(employeesData, employeesDataFile);
    if (writeSuccess) {
        // Refresh employees in memory
        employees = employeesData.map(
            (emp) =>
                new Employee(
                    emp.id,
                    emp.name,
                    emp.salary.basic,
                    emp.salary.hra,
                    emp.salary.special
                )
        );
        return true;
    } else {
        console.error('Error: Failed to write employee data to file.');
        return false;
    }
};

module.exports = {
    getEmployeeByID,
    getEmployeesByName,
    addNewEmployee,
};
