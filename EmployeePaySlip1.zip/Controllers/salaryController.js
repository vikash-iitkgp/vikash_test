const SalaryCalculator = require('../Classes/SalaryCalculator');
const EPF_PERCENTAGE = parseFloat(process.env.EPF_PERCENTAGE) || 12;
const TOTAL_WORKING_DAYS = parseInt(process.env.TOTAL_WORKING_DAYS) || 30;

const calculateEmployeeSalary = (employee, attendance) => {
    const salaryCalculator = new SalaryCalculator(employee, attendance, EPF_PERCENTAGE, TOTAL_WORKING_DAYS);
    const grossSalary = salaryCalculator.getGrossSalary();
    const attendanceSalary = salaryCalculator.calculateAttendanceBasedSalary();

    return {
        grossSalary,
        attendanceSalary,
    };
};

const displaySalaryDetails = (employee, salaryDetails) => {
    const { grossSalary, attendanceSalary } = salaryDetails;

    console.log(`\nEmployee: ${employee.name}`);
    console.log(`Gross Salary: ${grossSalary}`);
    console.log(`Calculated Salary: `);
    console.log(`
      - Basic: ${attendanceSalary.basic.toFixed(2)}
      - HRA: ${attendanceSalary.hra.toFixed(2)}
      - Special: ${attendanceSalary.special.toFixed(2)}
      - Attendance Salary: ${attendanceSalary.attendanceSalary.toFixed(2)}
      - Total EPF: ${attendanceSalary.totalEPF.toFixed(2)}
      - Net Salary: ${attendanceSalary.netSalary.toFixed(2)}
    `);
};

module.exports = {
    calculateEmployeeSalary,
    displaySalaryDetails,
};
