class SalaryCalculator {
    constructor(employee, attendance, epfPercentage, totalWorkingDays) {
        this.employee = employee;  // Employee object with salary details
        this.attendance = attendance;  // Attendance object for the employee
        this.epfPercentage = epfPercentage;  // EPF percentage
        this.totalWorkingDays = totalWorkingDays;  // Total working days in a month
    }

    // Get Gross Salary (Basic + HRA + Special)
    getGrossSalary() {
        return this.employee.basic + this.employee.hra + this.employee.special;
    }

    // Calculate Attendance Based Salary (dynamic EPF based on present days)
    calculateAttendanceBasedSalary() {
        try{
            const presentDays = this.attendance.getTotalAttendance();
            const dailySalary = this.getGrossSalary() / this.totalWorkingDays;
    
            // Dynamic EPF calculation based on the number of present days
            const dailyEPF = (this.employee.basic * this.epfPercentage) / 100 / this.totalWorkingDays;
            const totalEPF = dailyEPF * presentDays;
    
            // Calculate attendance-based salary
            const attendanceSalary = presentDays * dailySalary;
    
            // Breakup of salary components
            return {
                basic: (this.employee.basic / this.totalWorkingDays) * presentDays,
                hra: (this.employee.hra / this.totalWorkingDays) * presentDays,
                special: (this.employee.special / this.totalWorkingDays) * presentDays,
                attendanceSalary: attendanceSalary,
                totalEPF: totalEPF,
                netSalary: attendanceSalary - totalEPF
            };
        }catch(error){
            console.error('Error in calculating salaries data:', error.message);
        }
        
    }
}

module.exports = SalaryCalculator;
