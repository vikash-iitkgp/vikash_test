class Attendance {
    constructor(employeeID,leaveBalance, attendanceData) {
        this.employeeID = employeeID;
        this.leaveBalance= leaveBalance;
        this.attendanceData = attendanceData; // Array of attendance markers (e.g., ['P', 'A', 'WO', 'H'])
        this.leaveBalanceUsed=0;
    }


    // Get Attendance Summary
    getAttendanceSummary() {
        let presentDays = 0;
        let weeklyOffDays = 0;
        let halfDays = 0;
        let absentDays = 0;

        this.attendanceData.forEach(day => {
            if (day === 'P') {
                presentDays += 1;
            } else if (day === 'WO') {
                weeklyOffDays += 1;
            } else if (day === 'H') {
                halfDays += 1;  // Consider half days as 0.5 attendance
            } else if (day === 'A') {
                absentDays += 1;
            }
        });
        if(this.leaveBalance>(absentDays+halfDays/2)){
            this.leaveBalanceUsed=absentDays+halfDays/2;
        }else{
            this.leaveBalanceUsed=this.leaveBalance;
        }

        return {
            presentDays,
            weeklyOffDays,
            halfDays,
            absentDays
        };
    }

    // Get Total attendance including half days (0.5)
    getTotalAttendance() {
        const summary = this.getAttendanceSummary();
        const total=summary.presentDays + summary.weeklyOffDays + summary.halfDays/2 + this.leaveBalanceUsed;
        return total;
    }

    
}

module.exports = Attendance;
